
...

public class JPD06_5 {
    public static void main(String argv[]) {
        MISClass c1 = new MISClass();
        c1.put("Peter", new IM("Peter", 89, 980, 77, 69));
        ...
    }
}